---
visibility: hidden
redirect: https://github.com/retypeapp/retype/discussions/224
---